
URL: [My Website](https://genuine-chimera-b8fc87.netlify.app/)


URL: [Method test](https://genuine-chimera-b8fc87.netlify.app/methodtest.html)

URL: [Simple Web Component ](https://genuine-chimera-b8fc87.netlify.app/webcomponent.html)

URL: [Extra Credit ](https://genuine-chimera-b8fc87.netlify.app/extracredit.html)
